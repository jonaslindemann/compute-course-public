class Test:
    pass

print(a)
a = Test()
